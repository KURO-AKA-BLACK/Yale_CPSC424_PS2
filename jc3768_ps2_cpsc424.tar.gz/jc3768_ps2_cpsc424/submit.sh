#!/bin/bash
sbatch ./detail.sh